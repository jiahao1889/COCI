package com.COCI;

/**
 * The group user class.
 * @author COCI group
 * @since 2010-10-25
 */
public class Group extends User {
	
	public Group(String n,String p)
	{
		super(n, p);
	}
	public void AddAct()
	{
		
	}
	
	public void DelAct()
	{
		
	}
	
	public void ModifyAct()
	{
		
	}
	
	public void CollectApp()
	{
		
	}

}
