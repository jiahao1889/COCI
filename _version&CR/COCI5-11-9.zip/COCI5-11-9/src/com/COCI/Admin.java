package com.COCI;

/**
 * The administrator user class.
 * @author COCI group
 * @since 2010-10-25
 */
public class Admin extends User {
	
	public Admin(String n,String p)
	{
		super(n, p);
	}
	
	public void privilege()
	{
		
	}
	
	public void DelActivity()
	{
		
	}
	
	public void DelUser()
	{
		
	}	

}
