package com.COCI;

/**
 * The student user class.
 * @author COCI group
 * @since 2010-10-25
 */
public class Student extends User {
	public Student(String n,String p)
	{
		super(n, p);
	}
	
	public void Focus()
	{
		
	}
	
	public void Application()
	{
		
	}

}
