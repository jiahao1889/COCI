package com.COCI;

/**
 * The default user class.
 * @author COCI group
 * @since 2010-10-25
 */
public class User {
	
	public void Register()
	{
		
	}
	
	public void Login()
	{
		
	}
	
	protected int ID;
	protected String userName;
	protected String password;

}
