package com.COCI;

import java.util.Date;

/**
 * The activity class.
 * @author COCI group
 * @since 2010-10-25
 */
public class Activity {
	
	public void getID()
	{
		
	}
	
	public void getTitle()
	{
		
	}
	
	public void getDate()
	{
		
	}
	
	public void Modify()
	{
		
	}
	
	private int actID;
	private String title;
	private Date actDate;

}
