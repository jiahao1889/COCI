package com.COCI;

/**
 * The group user class.
 * @author COCI group
 * @since 2010-10-25
 */
public class Group extends User {
	
	public void AddAct()
	{
		
	}
	
	public void DelAct()
	{
		
	}
	
	public void ModifyAct()
	{
		
	}
	
	public void CollectApp()
	{
		
	}

}
