package com.COCI;

import java.util.ArrayList;

/**
 * The list of activities class.
 * @author COCI group
 * @since 2010-10-25
 */
public class ActList {
	
	public void AllActs()
	{
		
	}
	
	public void SearchByDate()
	{
		
	}
	
	public void SearchByFocus()
	{
		
	}
	
	public void SearchByGroup()
	{
		
	}
	
	public void DelAct()
	{
		
	}
	
	public void AddAct()
	{
		
	}
	
	private ArrayList<Activity> aList;

}
