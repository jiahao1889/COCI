package com.COCI;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * The default user class.
 * @author COCI group
 * @since 2010-10-25
 */
public class User {
	public User()
	{
		
	}
	//modified by CDS 2010-11-3
	public User(String n, String p)
	{
		userName = n;
		password = p;
	}
	
	//modified by CDS 2010-11-3
	public boolean Register(String n, String p, String e,String t) throws ClassNotFoundException, SQLException
	{
		String dbName="coci";
	    String tableName="user";
	    
	    Connection connection = SqlString.connectSql();
	    java.sql.Statement statement1=connection.createStatement();
		
		String sql="SELECT * FROM "+tableName;
	    ResultSet rs = statement1.executeQuery(sql);
	    
	    
	    while(rs.next()) {
	    	System.out.println(rs.getString("username"));
	    }
	    
	    
	    
	    rs = statement1.executeQuery(sql);
	    while(rs.next()) {
	    	if( rs.getString("username").equals(n) )
	    	{
                return false;
	    	}
	    }
       
	    sql = "INSERT INTO user(authority,username,passworld,email,telephone,create_date) VALUES(1,?,?,?,?,now())";
	    PreparedStatement Pstatement = connection.prepareStatement(sql);
	    Pstatement.setString(1,n);
	    Pstatement.setString(2,p);
	    Pstatement.setString(3,e);
	    Pstatement.setString(4,t);
	    Pstatement.executeUpdate();
	   
	    Pstatement.close();
        statement1.close();     // �ͷ�Statement����
	    connection.close();   // �رյ�MySQL������������
        rs.close();
      
        return true;

	}
	
	//modified by WQY 2010-11-3
	public boolean Login() throws ClassNotFoundException, SQLException
	{
		String dbName="coci";
	    String tableName="user";
	    
	    Connection connection = SqlString.connectSql();
	    java.sql.Statement statement1=connection.createStatement();
		
		String sql="SELECT * FROM USER WHERE username = '"+userName;
		sql += "' AND passworld ='";
		sql +=password;
		sql+="'";
	    ResultSet rs = statement1.executeQuery(sql);
	    
	    
	    if(rs.next()) {
	    	return true;
	    }
	    
        statement1.close();     // �ͷ�Statement����
	    connection.close();   // �رյ�MySQL������������
        rs.close();
      
		return false;
	}
	
	public String getName()
	{
		return userName;
	}
	

	
	protected int ID;
	protected String userName;
	protected String password;

}
