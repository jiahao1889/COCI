package com.COCI;

import java.sql.*;
import java.util.ArrayList;

/**
 * The list of activities class.
 * @author COCI group
 * @since 2010-10-25
 */
public class ActList {
	
	public ArrayList<Activity> AllActs() throws ClassNotFoundException, SQLException
	{
ArrayList<Activity> all = new ArrayList<Activity>();
		
	    String dbName="coci";
	    String tableName="act";
	    Connection connection = SqlString.connectSql();
	    Statement statement1=connection.createStatement();
        
	    statement1.executeUpdate("INSERT INTO act(name,creator_id,create_date) VALUES('2act',1,now())");
	    statement1.executeUpdate("INSERT INTO act(name,creator_id,create_date) VALUES('1act',2,now())");
	    statement1.executeUpdate("INSERT INTO act(name,creator_id,create_date) VALUES('3act',3,now())");
	    statement1.executeUpdate("INSERT INTO act(name,creator_id,create_date) VALUES('4act',4,now())");

        String sql="SELECT * FROM "+tableName;
	    ResultSet rs = statement1.executeQuery(sql);
	    
	    
	    while(rs.next()) {
	    	String n = rs.getString(2);
	    	int actid = rs.getInt(1);
	    	Timestamp cdate = rs.getTimestamp(4);
	    	Activity tmp = new Activity(n,actid,cdate);
	    	all.add(tmp);
	    }
	    
	    rs.close();
	    statement1.close();
	    connection.close();
		return all;
		
	}
	
	public void SearchByDate()
	{
		
	}
	
	public void SearchByFocus()
	{
		
	}
	
	public void SearchByGroup()
	{
		
	}
	
	public void DelAct()
	{
		
	}
	
	public void AddAct()
	{
		
	}
	//modified by WQY QJ
	//private ArrayList<Activity> aList;

}
